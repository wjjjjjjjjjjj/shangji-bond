@echo off
setlocal
set "XHS_DIR=%USERPROFILE%\AppData\Local\last30days\xiaohongshu"
cd /d "%XHS_DIR%" || exit /b 1
set "COOKIES_PATH=%XHS_DIR%\cookies.json"
"%XHS_DIR%\v2.7.4\xiaohongshu-login.exe"
if errorlevel 1 pause
