"""本机笔记检索服务。只向本机页面和指定站点开放只读查询。"""
import argparse
import importlib
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
import types
import webbrowser
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, ProxyHandler, build_opener, urlopen
from urllib.error import URLError

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"
PORT = 18731
LOCAL = f"http://127.0.0.1:{PORT}"
ORIGINS = {LOCAL, f"http://localhost:{PORT}", "https://shangji.bond"}
HOME = Path.home()
ZONE = timezone(timedelta(hours=8))
LOCK = threading.Lock()
DEPTHS = {"quick", "default", "deep"}

def api_base():
    value = os.environ.get("XIAOHONGSHU_API_BASE")
    cfg = HOME / ".config/last30days/.env"
    if not value and cfg.is_file():
        for line in cfg.read_text(encoding="utf-8-sig").splitlines():
            if line.strip().startswith("XIAOHONGSHU_API_BASE="):
                value = line.split("=", 1)[1].strip().strip('"').strip("'")
                break
    return (value or "http://127.0.0.1:18060").rstrip("/")

def open_api(request, timeout):
    url = request.full_url if isinstance(request, Request) else request
    if urlsplit(url).hostname in {"localhost", "127.0.0.1", "::1"}:
        return build_opener(ProxyHandler({})).open(request, timeout=timeout)
    return urlopen(request, timeout=timeout)

def source_client():
    skill = Path(os.environ.get("LAST30DAYS_SKILL_DIR", HOME / ".codex/skills/last30days"))
    scripts = skill / "scripts"
    if not (scripts / "lib/xiaohongshu_api.py").is_file():
        raise ValueError("未找到 last30days 的小红书适配器，请检查安装目录。")
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    return importlib.import_module("lib.xiaohongshu_api")

def status():
    # The source can search even if its separate browser-based login probe times out.
    with open_api(api_base()+"/health", timeout=6) as stream:
        data = json.load(stream)
    if not isinstance(data, dict) or not (data.get("success") is True or data.get("status") in ("ok", "healthy")):
        raise RuntimeError("数据源健康检查返回了无法识别的响应。")
    return {"ready": True, "message": "小红书服务已连接，登录有效性以实际检索为准。"}

def count(value):
    match = re.fullmatch(r"(\d+(?:\.\d+)?)([万亿]?)", str(value).strip().replace(",", ""))
    return int(float(match[1])*{"":1, "万":10000, "亿":100000000}[match[2]]) if match else None

def normalize(item, card):
    metrics = card.get("interactInfo") or {}
    cover = card.get("cover") or {}
    author = card.get("user") or {}
    stamp = card.get("time")
    published = item.get("date")
    try:
        if stamp and int(stamp) > 0:
            published = datetime.fromtimestamp(int(stamp) / 1000, ZONE).strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError, OSError, OverflowError):
        pass
    return {"title":item.get("title"), "snippet":item.get("snippet"), "url":item["url"],
            "author":author.get("nickName") or author.get("nickname"), "type":card.get("type"),
            "date":published, "cover":cover.get("urlDefault") or cover.get("urlPre"),
            "likes":count(metrics.get("likedCount")), "favorites":count(metrics.get("collectedCount")),
            "comments":count(metrics.get("commentCount")), "shares":count(metrics.get("sharedCount")),
            "reads":None}

def search(keyword, depth):
    client = source_client()
    cards = {}
    # Retain card metadata alongside the installed adapter's normalized source items.
    class Transport:
        HTTPError = client.http.HTTPError
        @staticmethod
        def post(url, payload, timeout, retries):
            if urlsplit(url).hostname in {"localhost", "127.0.0.1", "::1"}:
                req = Request(url, data=json.dumps(payload).encode(), headers={"Content-Type":"application/json"})
                with open_api(req, timeout) as stream:
                    response = json.load(stream)
            else:
                response = client.http.post(url, payload, timeout=timeout, retries=retries)
            for feed in ((response.get("data") or {}).get("feeds") or []) if isinstance(response, dict) else []:
                if isinstance(feed, dict) and isinstance(feed.get("noteCard"), dict):
                    card = feed["noteCard"]
                    cards[str(feed.get("id") or card.get("noteId") or "")] = card
            return response
    original = client.search_feeds
    fetch = types.FunctionType(original.__code__, {**original.__globals__, "http":Transport}, original.__name__, original.__defaults__)
    now = datetime.now(ZONE)
    days = {"quick":1, "default":7, "deep":183}[depth]
    items = fetch(keyword,(now-timedelta(days=days)).date().isoformat(),now.date().isoformat(),api_base(),depth)
    seen, output = set(), []
    for item in items:
        ident = urlsplit(item["url"]).path.split("/")[-1]
        if not ident or ident in seen:
            continue
        seen.add(ident)
        output.append(normalize(item, cards.get(ident, {})))
    return {"items":output, "at":now.strftime("%Y-%m-%d %H:%M 北京时间")}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def allowed(self):
        return self.headers.get("Host") in {f"127.0.0.1:{PORT}", f"localhost:{PORT}"} and (not self.headers.get("Origin") or self.headers["Origin"] in ORIGINS)

    def send_body(self, code, data=b"", content_type="application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        origin = self.headers.get("Origin")
        if origin in ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Private-Network", "true")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()
        if data:
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def reply(self, code, result):
        self.send_body(code, json.dumps(result, ensure_ascii=False).encode())

    def do_OPTIONS(self):
        self.send_body(204 if self.allowed() else 403)

    def do_GET(self):
        if not self.allowed():
            return self.reply(403, {"error":"来源不受支持"})
        path = urlsplit(self.path).path
        if path == "/api/identity":
            return self.reply(200, {"app":"hongjian-note-search"})
        if path == "/api/status":
            try:
                return self.reply(200, status())
            except Exception as exc:
                return self.reply(503, {"error":problem(exc)})
        name = path.lstrip("/") or "index.html"
        if name not in {"index.html","app.js","style.css","sample.js"} and not re.fullmatch(r"covers/\d+\.jpg",name):
            return self.send_body(404)
        target = WEB / name
        if not target.is_file():
            return self.send_body(404)
        mime = {".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".jpg":"image/jpeg"}[target.suffix]
        self.send_body(200, target.read_bytes(), mime)

    def do_POST(self):
        if not self.allowed() or not self.headers.get("Content-Type","").startswith("application/json"):
            return self.reply(403, {"error":"不支持的请求"})
        if self.path != "/api/search":
            return self.send_body(404)
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 4096:
                raise ValueError
            data = json.loads(self.rfile.read(length))
            keyword, depth = data["keyword"].strip(), data["depth"]
            if not 0 < len(keyword) <= 80 or depth not in DEPTHS:
                raise ValueError
        except (ValueError, KeyError, AttributeError, TypeError):
            return self.reply(400, {"error":"请输入 1 至 80 个字符的关键词并选择有效时间范围。"})
        if not LOCK.acquire(blocking=False):
            return self.reply(429, {"error":"已有检索正在进行，请稍后重试。"})
        try:
            if api_base() == "http://127.0.0.1:18060":
                child = start_source()
                if child is not None:
                    self.server.source_child = child
            return self.reply(200, search(keyword, depth))
        except Exception as err:
            print(f"检索失败 ({type(err).__name__})", flush=True)
            return self.reply(502, {"error":problem(err)})
        finally:
            LOCK.release()

def error_code(exc):
    reason = getattr(exc, "reason", exc)
    return getattr(reason, "winerror", None) or getattr(reason, "errno", None)

def problem(exc):
    code = error_code(exc)
    if code in (10013, 13):
        return "当前进程无权访问本机接口（WinError 10013）。请在 Windows 桌面运行启动程序，核对桌面会话的连接结果。"
    if code in (10061, 111):
        return "目标端口未接受连接。请运行启动程序以启动已安装的小红书服务。"
    if isinstance(exc, TimeoutError) or isinstance(getattr(exc, "reason", None), TimeoutError):
        return "小红书服务响应超时。请确认登录窗口已完成，并稍后重新检查。"
    if isinstance(exc, (RuntimeError, ValueError)) or type(exc).__name__ == "HTTPError":
        return str(exc)
    return "小红书接口检测失败（" + type(exc).__name__ + ("，错误码 " + str(code) if code else "") + "）。"

def start_source():
    if api_base() != "http://127.0.0.1:18060":
        return None
    endpoint = ("127.0.0.1", 18060)
    try:
        with socket.create_connection(endpoint, timeout=2):
            return None
    except OSError as exc:
        if error_code(exc) not in (10061, 111):
            raise
    directory = HOME / "AppData/Local/last30days/xiaohongshu"
    versions = [p for p in directory.glob("v*/xiaohongshu-mcp.exe") if re.fullmatch(r"v[0-9]+(?:\.[0-9]+)*", p.parent.name)]
    executable = max(versions, key=lambda p: tuple(map(int, p.parent.name[1:].split("."))), default=directory / "xiaohongshu-mcp.exe")
    if not executable.is_file():
        raise RuntimeError("本机端口 18060 没有服务，且未找到已安装的小红书服务程序。")
    log_path = Path(tempfile.gettempdir()) / "note-search-source.log"
    with log_path.open("ab") as log:
        child = subprocess.Popen(
        [str(executable), "-port", "127.0.0.1:18060"], cwd=directory,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        stdout=log, stderr=subprocess.STDOUT)
    try:
        for _ in range(40):
            if child.poll() is not None:
                raise RuntimeError(f"小红书服务启动后退出（退出码 {child.returncode}）。")
            try:
                with socket.create_connection(endpoint, timeout=1):
                    return child
            except OSError as exc:
                if error_code(exc) not in (10061, 111):
                    raise
            time.sleep(0.25)
        raise RuntimeError("小红书服务启动超时，端口 18060 尚未就绪。")
    except BaseException:
        if child.poll() is None:
            child.terminate()
        raise

def check_source():
    try:
        source_client()
        result = status()
        return result["ready"], result["message"]
    except Exception as exc:
        return False, problem(exc)

def diagnostics():
    owned = None
    try:
        print("正在检测当前 Windows 会话到小红书服务的连接……", flush=True)
        owned = start_source()
        ready, detail = check_source()
    except Exception as exc:
        ready, detail = False, problem(exc)
    finally:
        if owned is not None and owned.poll() is None:
            owned.terminate()
    print(detail, flush=True)
    return 0 if ready else 1

if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--open", action="store_true")
    parser.add_argument("--check", action="store_true")
    args=parser.parse_args()
    if args.check:
        sys.exit(diagnostics())
    try:
        server=ThreadingHTTPServer(("127.0.0.1",PORT),Handler)
    except OSError:
        # Reopen an already running copy only after verifying its application marker.
        try:
            with open_api(LOCAL + "/api/identity",timeout=2) as response:
                existing=json.load(response).get("app")=="hongjian-note-search"
        except Exception:
            existing=False
        if existing and args.open:
            # The running website can outlive its source process.
            child = None
            try:
                child = start_source()
                ready, detail = check_source()
                print(detail, flush=True)
                webbrowser.open(LOCAL)
                if child is not None:
                    print("请保持此窗口打开，小红书数据源正在此窗口运行。", flush=True)
                    sys.exit(child.wait())
                sys.exit(0 if ready else 1)
            except KeyboardInterrupt:
                if child is not None and child.poll() is None:
                    child.terminate()
                sys.exit(0)
            except Exception as exc:
                raise SystemExit(problem(exc))
        raise SystemExit("本机服务端口 18731 无法使用。请检查是否已有应用占用该端口。")
    owned = None
    try:
        try:
            owned = server.source_child = start_source()
            ready, diagnostic = check_source()
        except Exception as exc:
            ready, diagnostic = False, problem(exc)
        print(diagnostic, flush=True)
        print(f"笔记检索  {LOCAL}  保留此窗口即可使用。",flush=True)
        if args.open:
            webbrowser.open(LOCAL)
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        owned = getattr(server, "source_child", owned)
        if owned and owned.poll() is None:
            owned.terminate()
